#' Removes na in a data
#' 
#' Using a function to go thru each column and cleaning it out by removing NA values. 
#' 
#' @param data selects the data column 
#' @param column 


remove_nas <- function(data, column) {
  clean <- data %>% 
    na.omit(data) %>% 
    select(weight)
  return(clean)
  
  
}